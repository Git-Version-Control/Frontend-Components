import React from 'react';
import { Line } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';
import { motion } from 'framer-motion';

// Register chart.js components
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

const ProductOverviewLineGraph = () => {
  const analytics = {
    products: [
      {
        name: "Product A",
        documents: 40,
        users: 10,
        chats: 15,
      },
      {
        name: "Product B",
        documents: 30,
        users: 15,
        chats: 10,
      },
      {
        name: "Product C",
        documents: 50,
        users: 20,
        chats: 20,
      },
    ],
  };

  // Prepare data for the line chart
  const productNames = analytics.products.map((product) => product.name);
  const documentCounts = analytics.products.map((product) => product.documents);
  const userCounts = analytics.products.map((product) => product.users);
  const chatCounts = analytics.products.map((product) => product.chats);

  const data = {
    labels: productNames,
    datasets: [
      {
        label: 'Documents',
        data: documentCounts,
        borderColor: '#4caf50',
        backgroundColor: 'rgba(76, 175, 80, 0.2)',
        fill: true,
      },
      {
        label: 'Users',
        data: userCounts,
        borderColor: '#2196f3',
        backgroundColor: 'rgba(33, 150, 243, 0.2)',
        fill: true,
      },
      {
        label: 'Chats',
        data: chatCounts,
        borderColor: '#ff9800',
        backgroundColor: 'rgba(255, 152, 0, 0.2)',
        fill: true,
      },
    ],
  };

  const options = {
    responsive: true,
    scales: {
      x: {
        title: {
          display: true,
          text: 'Products',
        },
      },
      y: {
        title: {
          display: true,
          text: 'Count',
        },
      },
    },
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-xl mb-8">
      <h2 className="text-2xl font-bold text-gray-700 mb-4">Products Overview</h2>
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.5 }}
      >
        <Line data={data} options={options} />
      </motion.div>
    </div>
  );
};

export default ProductOverviewLineGraph;
