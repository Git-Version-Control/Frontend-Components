import { motion } from 'framer-motion';
import React from 'react'

const ProductOverviewCircularMeter = () => {
    const analytics = {
        documents: 120,
        chats: 45,
        feedback: {
          positive: 30,
          neutral: 10,
          negative: 5,
        },
        questions: [
          { question: "What is React?", count: 10 },
          { question: "How to use hooks?", count: 15 },
          { question: "What is Redux?", count: 20 },
        ],
        products: [
          {
            name: "Product A",
            documents: 40,
            users: 10,
            chats: 15,
            totalDocuments: 50,
            totalUsers: 20,
            totalChats: 20,
          },
          {
            name: "Product B",
            documents: 30,
            users: 15,
            chats: 10,
            totalDocuments: 50,
            totalUsers: 20,
            totalChats: 20,
          },
          {
            name: "Product C",
            documents: 50,
            users: 20,
            chats: 20,
            totalDocuments: 50,
            totalUsers: 20,
            totalChats: 20,
          },
        ],
      };
  return (
    // Product List with Counts
    <div className="bg-white p-6 rounded-lg shadow-xl mb-8">
    <h2 className="text-2xl font-bold text-gray-700 mb-4">
      Products Overview
    </h2>
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {analytics.products.map((product, index) => (
        <motion.div
          key={index}
          className="bg-gray-50 p-4 rounded-lg shadow-lg flex flex-col items-center"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.2, duration: 0.5 }}
        >
          <h3 className="text-xl font-semibold mb-4">{product.name}</h3>
          <div className="flex space-x-4 items-center">
            {/* Document Count */}
            <div className="relative w-24 h-24">
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="50%"
                  cy="50%"
                  r="40%"
                  stroke="#e0e0e0"
                  strokeWidth="8"
                  fill="none"
                />
                <motion.circle
                  cx="50%"
                  cy="50%"
                  r="40%"
                  stroke="#4caf50"
                  strokeWidth="8"
                  fill="none"
                  strokeDasharray="252"
                  strokeDashoffset={
                    252 -
                    (252 * product.documents) / product.totalDocuments
                  }
                  animate={{
                    strokeDashoffset:
                      252 -
                      (252 * product.documents) / product.totalDocuments,
                  }}
                  transition={{ duration: 1 }}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-lg font-bold">
                  {product.documents}
                </span>
              </div>
              <p className="text-sm text-gray-600 text-center mt-1">
                Documents
              </p>
            </div>

            {/* User Count */}
            <div className="relative w-24 h-24">
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="50%"
                  cy="50%"
                  r="40%"
                  stroke="#e0e0e0"
                  strokeWidth="8"
                  fill="none"
                />
                <motion.circle
                  cx="50%"
                  cy="50%"
                  r="40%"
                  stroke="#2196f3"
                  strokeWidth="8"
                  fill="none"
                  strokeDasharray="252"
                  strokeDashoffset={
                    252 - (252 * product.users) / product.totalUsers
                  }
                  animate={{
                    strokeDashoffset:
                      252 - (252 * product.users) / product.totalUsers,
                  }}
                  transition={{ duration: 1 }}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-lg font-bold">{product.users}</span>
              </div>
              <p className="text-sm text-gray-600 text-center mt-1">
                Users
              </p>
            </div>

            {/* Chat Count */}
            <div className="relative w-24 h-24">
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="50%"
                  cy="50%"
                  r="40%"
                  stroke="#e0e0e0"
                  strokeWidth="8"
                  fill="none"
                />
                <motion.circle
                  cx="50%"
                  cy="50%"
                  r="40%"
                  stroke="#ff9800"
                  strokeWidth="8"
                  fill="none"
                  strokeDasharray="252"
                  strokeDashoffset={
                    252 - (252 * product.chats) / product.totalChats
                  }
                  animate={{
                    strokeDashoffset:
                      252 - (252 * product.chats) / product.totalChats,
                  }}
                  transition={{ duration: 1 }}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-lg font-bold">{product.chats}</span>
              </div>
              <p className="text-sm text-gray-600 text-center mt-1">
                Chats
              </p>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  </div>
  )
}

export default ProductOverviewCircularMeter