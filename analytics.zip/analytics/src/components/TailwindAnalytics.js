// Import necessary libraries
import React, { useState, useEffect } from 'react';
import { Bar, Pie } from 'react-chartjs-2';
import { Chart as ChartJS, registerables } from 'chart.js';


ChartJS.register(...registerables);

const AnalyticsPage = () => {
    const [category, setCategory] = useState('');
    const [user, setUser] = useState('');
    const [animatedCounts, setAnimatedCounts] = useState({ documents: 0, chats: 0 });

    // Mock data for demonstration
    const analyticsData = {
        documents: 120,
        chats: 45,
        feedback: {
            positive: 30,
            neutral: 10,
            negative: 5,
        },
        questions: [
            { question: 'What is React?', count: 10 },
            { question: 'How to use hooks?', count: 15 },
            { question: 'What is Redux?', count: 20 },
        ],
    };

    useEffect(() => {
        // Animating counts from 0 to the final value
        let docCount = 0;
        let chatCount = 0;
        const interval = setInterval(() => {
            docCount = Math.min(docCount + 1, analyticsData.documents);
            chatCount = Math.min(chatCount + 1, analyticsData.chats);

            setAnimatedCounts({ documents: docCount, chats: chatCount });

            if (docCount === analyticsData.documents && chatCount === analyticsData.chats) {
                clearInterval(interval);
            }
        }, 10);

        return () => clearInterval(interval);
    }, []);

    // Chart configurations
    const feedbackData = {
        labels: ['Positive', 'Neutral', 'Negative'],
        datasets: [
            {
                label: 'Feedback',
                data: [
                    analyticsData.feedback.positive,
                    analyticsData.feedback.neutral,
                    analyticsData.feedback.negative,
                ],
                backgroundColor: ['#4caf50', '#ffeb3b', '#f44336'],
                hoverBackgroundColor: ['#388e3c', '#fbc02d', '#d32f2f'],
                borderWidth: 2,
            },
        ],
    };

    const questionData = {
        labels: analyticsData.questions.map((q) => q.question),
        datasets: [
            {
                label: 'Question Frequency',
                data: analyticsData.questions.map((q) => q.count),
                backgroundColor: ['#42a5f5', '#66bb6a', '#ffa726'],
                hoverBackgroundColor: ['#1e88e5', '#388e3c', '#f57c00'],
                borderWidth: 2,
            },
        ],
    };

    // Event handlers
    const handleCategoryChange = (event) => {
        setCategory(event.target.value);
        // Update data based on selected category (API calls or state updates)
    };

    const handleUserChange = (event) => {
        setUser(event.target.value);
        // Update data based on selected user (API calls or state updates)
    };

    return (
        <div className="p-6">
            {/* Header */}
            <div className="text-center mb-8">
                <h1 className="text-4xl font-bold">Analytics Dashboard</h1>
            </div>

            {/* Filters */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                <select
                    value={category}
                    onChange={handleCategoryChange}
                    className="w-full p-3 border border-gray-300 rounded-lg shadow-sm"
                >
                    <option value="">Select Category</option>
                    <option value="Category1">Category 1</option>
                    <option value="Category2">Category 2</option>
                </select>

                <select
                    value={user}
                    onChange={handleUserChange}
                    className="w-full p-3 border border-gray-300 rounded-lg shadow-sm"
                >
                    <option value="">Select User</option>
                    <option value="User1">User 1</option>
                    <option value="User2">User 2</option>
                </select>
            </div>

            {/* Document & Chat Count */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                <div className="bg-blue-100 p-6 rounded-lg shadow-md text-center">
                    <h2 className="text-xl font-semibold">Document Count</h2>
                    <p className="text-3xl font-bold animate-pulse">{animatedCounts.documents}</p>
                </div>

                <div className="bg-pink-100 p-6 rounded-lg shadow-md text-center">
                    <h2 className="text-xl font-semibold">Chat Count</h2>
                    <p className="text-3xl font-bold animate-pulse">{animatedCounts.chats}</p>
                </div>
            </div>

            {/* Feedback Chart */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                <div className="bg-white p-6 rounded-lg shadow-md">
                    <h2 className="text-xl font-semibold mb-4">Feedback Distribution</h2>
                    <Pie
                        data={feedbackData}
                        options={{
                            plugins: {
                                legend: {
                                    position: 'bottom',
                                },
                                tooltip: {
                                    callbacks: {
                                        label: function (context) {
                                            return `${context.label}: ${context.raw}`;
                                        },
                                    },
                                },
                            },
                            animation: {
                                animateScale: true,
                                animateRotate: true,
                            },
                        }}
                    />
                </div>

                {/* Question Frequency Chart */}
                <div className="bg-white p-6 rounded-lg shadow-md">
                    <h2 className="text-xl font-semibold mb-4">Question Frequency</h2>
                    <Bar
                        data={questionData}
                        options={{
                            plugins: {
                                legend: {
                                    display: false,
                                },
                                tooltip: {
                                    callbacks: {
                                        label: function (context) {
                                            return `${context.label}: ${context.raw}`;
                                        },
                                    },
                                },
                            },
                            animation: {
                                duration: 1500,
                                easing: 'easeOutBounce',
                            },
                        }}
                    />
                </div>
            </div>
        </div>
    );
};

export default AnalyticsPage;
