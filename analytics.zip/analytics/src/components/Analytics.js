import React, { useState, useEffect } from "react";
import { Bar, Pie } from "react-chartjs-2";
import { Chart as ChartJS, registerables } from "chart.js";
import { motion } from "framer-motion";
import "tailwindcss/tailwind.css";
import ProductOverviewLine from "./ProductOverviewLine";
import ProductOverviewCircularMeter from "./ProductOverviewCircularMeter";

ChartJS.register(...registerables);

export const AnalyticsPage = () => {
  const [category, setCategory] = useState("");
  const [user, setUser] = useState("");
  const [animatedCounts, setAnimatedCounts] = useState({
    documents: 0,
    chats: 0,
  });
  const [loaded, setLoaded] = useState(false);

  // Mock data for demonstration
  const analyticsData = {
    documents: 120,
    chats: 45,
    feedback: {
      positive: 30,
      neutral: 10,
      negative: 5,
    },
    questions: [
      { question: "What is React?", count: 10 },
      { question: "How to use hooks?", count: 15 },
      { question: "What is Redux?", count: 20 },
    ],
  };

  useEffect(() => {
    // Animating counts from 0 to the final value
    let docCount = 0;
    let chatCount = 0;
    const interval = setInterval(() => {
      docCount = Math.min(docCount + 1, analyticsData.documents);
      chatCount = Math.min(chatCount + 1, analyticsData.chats);

      setAnimatedCounts({ documents: docCount, chats: chatCount });

      if (
        docCount === analyticsData.documents &&
        chatCount === analyticsData.chats
      ) {
        clearInterval(interval);
        setLoaded(true);
      }
    }, 10);

    return () => clearInterval(interval);
  }, []);

  // Chart configurations
  const feedbackData = {
    labels: ["Positive", "Neutral", "Negative"],
    datasets: [
      {
        label: "Feedback",
        data: [
          analyticsData.feedback.positive,
          analyticsData.feedback.neutral,
          analyticsData.feedback.negative,
        ],
        backgroundColor: ["#4caf50", "#ffeb3b", "#f44336"],
        hoverBackgroundColor: ["#388e3c", "#fbc02d", "#d32f2f"],
        borderWidth: 2,
      },
    ],
  };


  const questionData = {
    labels: analyticsData.questions.map((q) => q.question),
    datasets: [
      {
        label: "Question Frequency",
        data: analyticsData.questions.map((q) => q.count),
        backgroundColor: ["#42a5f5", "#66bb6a", "#ffa726"],
        hoverBackgroundColor: ["#1e88e5", "#388e3c", "#f57c00"],
        borderWidth: 2,
      },
    ],
  };

  // Event handlers
  const handleCategoryChange = (event) => {
    setCategory(event.target.value);
  };

  const handleUserChange = (event) => {
    setUser(event.target.value);
  };

  return (
    <>
      <div className="p-6 min-h-screen">
        {/* Header */}
        <motion.div
          className="text-center mb-8"
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          <h1 className="text-5xl font-extrabold text-black drop-shadow-lg">
            Stunning Analytics Dashboard
          </h1>
        </motion.div>
        
        <ProductOverviewLine />
        {/* <ProductOverviewCircularMeter/> */}

        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          <motion.select
            value={category}
            onChange={handleCategoryChange}
            className="w-full p-3 border border-gray-300 rounded-lg shadow-lg bg-white"
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <option value="">Select Category</option>
            <option value="Category1">Category 1</option>
            <option value="Category2">Category 2</option>
          </motion.select>

          <motion.select
            value={user}
            onChange={handleUserChange}
            className="w-full p-3 border border-gray-300 rounded-lg shadow-lg bg-white"
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <option value="">Select User</option>
            <option value="User1">User 1</option>
            <option value="User2">User 2</option>
          </motion.select>
        </div>
        {/* Celebration Animation */}
        {loaded && (
          <motion.div
            className="fixed top-0 left-0 w-full h-full flex justify-center items-center pointer-events-none"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1 }}
          >
            {/* Placeholder for celebration animation */}
          </motion.div>
        )}
        {/* Circular Progress for Document & Chat Counts */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          <motion.div
            className="flex flex-col items-center bg-gray-50 p-6 rounded-lg shadow-xl"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
          >
            <h2 className="text-xl font-semibold mb-4 text-gray-700">
              Document Count
            </h2>
            <div className="relative w-36 h-36">
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="50%"
                  cy="50%"
                  r="40%"
                  stroke="#e0e0e0"
                  strokeWidth="10"
                  fill="none"
                />
                <motion.circle
                  cx="50%"
                  cy="50%"
                  r="40%"
                  stroke="#4caf50"
                  strokeWidth="10"
                  fill="none"
                  strokeDasharray="252"
                  strokeDashoffset={
                    252 -
                    (252 * animatedCounts.documents) / analyticsData.documents
                  }
                  animate={{
                    strokeDashoffset:
                      252 -
                      (252 * animatedCounts.documents) /
                        analyticsData.documents,
                  }}
                  transition={{ duration: 1 }}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-2xl font-bold text-gray-800">
                  {animatedCounts.documents}
                </span>
              </div>
            </div>
          </motion.div>

          <motion.div
            className="flex flex-col items-center bg-gray-50 p-6 rounded-lg shadow-xl"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
          >
            <h2 className="text-xl font-semibold mb-4 text-gray-700">
              Chat Count
            </h2>
            <div className="relative w-36 h-36">
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="50%"
                  cy="50%"
                  r="40%"
                  stroke="#e0e0e0"
                  strokeWidth="10"
                  fill="none"
                />
                <motion.circle
                  cx="50%"
                  cy="50%"
                  r="40%"
                  stroke="#ff9800"
                  strokeWidth="10"
                  fill="none"
                  strokeDasharray="252"
                  strokeDashoffset={
                    252 - (252 * animatedCounts.chats) / analyticsData.chats
                  }
                  animate={{
                    strokeDashoffset:
                      252 - (252 * animatedCounts.chats) / analyticsData.chats,
                  }}
                  transition={{ duration: 1 }}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-2xl font-bold text-gray-800">
                  {animatedCounts.chats}
                </span>
              </div>
            </div>
          </motion.div>
        </div>
        {/* Feedback and Question Charts */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          <motion.div
            className="bg-gray-50 p-6 rounded-lg shadow-xl"
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.3, duration: 0.5 }}
          >
            <h2 className="text-xl font-semibold mb-4 text-gray-700">
              Feedback Distribution
            </h2>
            <Pie
              data={{
                labels: ["Positive", "Neutral", "Negative"],
                datasets: [
                  {
                    label: "Feedback",
                    data: [30, 10, 5],
                    backgroundColor: ["#bbdefb", "#c8e6c9", "#ffcdd2"],
                    borderColor: ["#90caf9", "#a5d6a7", "#ef9a9a"],
                    borderWidth: 2,
                  },
                ],
              }}
              options={{
                plugins: {
                  legend: {
                    position: "bottom",
                    labels: { color: "#333" },
                  },
                },
              }}
            />
          </motion.div>

          <motion.div
            className="bg-gray-50 p-6 rounded-lg shadow-xl"
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.5, duration: 0.5 }}
          >
            <h2 className="text-xl font-semibold mb-4 text-gray-700">
              Question Frequency
            </h2>
            <Bar
              data={{
                labels: [
                  "What is React?",
                  "How to use hooks?",
                  "What is Redux?",
                ],
                datasets: [
                  {
                    label: "Question Frequency",
                    data: [10, 15, 20],
                    backgroundColor: ["#ffcc80", "#b39ddb", "#80cbc4"],
                    borderColor: ["#ffa726", "#9575cd", "#4db6ac"],
                    borderWidth: 2,
                  },
                ],
              }}
              options={{
                plugins: {
                  legend: { display: false },
                  tooltip: { enabled: true },
                },
              }}
            />
          </motion.div>
        </div>
      </div>
    </>
  );
};

// { <div className="p-6 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 min-h-screen">
//     {/* Header */}
//     <motion.div
//         className="text-center mb-8"
//         initial={{ opacity: 0, y: -50 }}
//         animate={{ opacity: 1, y: 0 }}
//         transition={{ duration: 1 }}>
//         <h1 className="text-5xl font-extrabold text-white drop-shadow-lg">Stunning Analytics Dashboard</h1>
//     </motion.div>

//     {/* Filters */}
//     <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
//         <motion.select
//             value={category}
//             onChange={handleCategoryChange}
//             className="w-full p-3 border border-gray-300 rounded-lg shadow-lg bg-white"
//             initial={{ scale: 0.9 }}
//             animate={{ scale: 1 }}
//             transition={{ duration: 0.5 }}
//         >
//             <option value="">Select Category</option>
//             <option value="Category1">Category 1</option>
//             <option value="Category2">Category 2</option>
//         </motion.select>

//         <motion.select
//             value={user}
//             onChange={handleUserChange}
//             className="w-full p-3 border border-gray-300 rounded-lg shadow-lg bg-white"
//             initial={{ scale: 0.9 }}
//             animate={{ scale: 1 }}
//             transition={{ duration: 0.5 }}
//         >
//             <option value="">Select User</option>
//             <option value="User1">User 1</option>
//             <option value="User2">User 2</option>
//         </motion.select>
//     </div>

//     {/* Document & Chat Count */}
//     <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
//         <motion.div
//             className="bg-blue-600 p-6 rounded-lg shadow-xl text-center text-white hover:scale-105 transition-transform"
//             initial={{ y: 50, opacity: 0 }}
//             animate={{ y: 0, opacity: 1 }}
//             transition={{ delay: 0.2, duration: 0.8 }}>
//             <h2 className="text-xl font-bold">Document Count</h2>
//             <p className="text-4xl font-extrabold animate-pulse">{animatedCounts.documents}</p>
//         </motion.div>

//         <motion.div
//             className="bg-pink-600 p-6 rounded-lg shadow-xl text-center text-white hover:scale-105 transition-transform"
//             initial={{ y: 50, opacity: 0 }}
//             animate={{ y: 0, opacity: 1 }}
//             transition={{ delay: 0.4, duration: 0.8 }}>
//             <h2 className="text-xl font-bold">Chat Count</h2>
//             <p className="text-4xl font-extrabold animate-pulse">{animatedCounts.chats}</p>
//         </motion.div>
//     </div>

//     {/* Feedback Chart */}
//     <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
//         <motion.div
//             className="bg-white p-6 rounded-lg shadow-xl"
//             initial={{ scale: 0.9 }}
//             animate={{ scale: 1 }}
//             transition={{ delay: 0.3, duration: 0.5 }}>
//             <h2 className="text-xl font-semibold mb-4">Feedback Distribution</h2>
//             <Pie
//                 data={feedbackData}
//                 options={{
//                     plugins: {
//                         legend: {
//                             position: 'bottom',
//                         },
//                         tooltip: {
//                             callbacks: {
//                                 label: function (context) {
//                                     return `${context.label}: ${context.raw}`;
//                                 },
//                             },
//                         },
//                     },
//                     animation: {
//                         animateScale: true,
//                         animateRotate: true,
//                     },
//                 }}
//             />
//         </motion.div>

//         {/* Question Frequency Chart */}
//         <motion.div
//             className="bg-white p-6 rounded-lg shadow-xl"
//             initial={{ scale: 0.9 }}
//             animate={{ scale: 1 }}
//             transition={{ delay: 0.5, duration: 0.5 }}>
//             <h2 className="text-xl font-semibold mb-4">Question Frequency</h2>
//             <Bar
//                 data={questionData}
//                 options={{
//                     plugins: {
//                         legend: {
//                             display: false,
//                         },
//                         tooltip: {
//                             callbacks: {
//                                 label: function (context) {
//                                     return `${context.label}: ${context.raw}`;
//                                 },
//                             },
//                         },
//                     },
//                     animation: {
//                         duration: 1500,
//                         easing: 'easeOutBounce',
//                     },
//                 }}
//             />
//         </motion.div>
//     </div>
// </div>}
