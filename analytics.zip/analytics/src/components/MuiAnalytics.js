// Import necessary libraries
import React, { useState } from 'react';
import { Grid, Typography, Select, MenuItem, Card, CardContent } from '@mui/material';
import { Bar, Pie, Line } from 'react-chartjs-2';
import { Chart as ChartJS, registerables } from 'chart.js';

ChartJS.register(...registerables);

const MuiAnalytics = () => {
    const [category, setCategory] = useState('');
    const [user, setUser] = useState('');

    // Mock data for demonstration
    const analyticsData = {
        documents: 120,
        chats: 45,
        feedback: {
            positive: 30,
            neutral: 10,
            negative: 5,
        },
        questions: [
            { question: 'What is React?', count: 10 },
            { question: 'How to use hooks?', count: 15 },
            { question: 'What is Redux?', count: 20 },
        ],
    };

    // Chart configurations
    const feedbackData = {
        labels: ['Positive', 'Neutral', 'Negative'],
        datasets: [
            {
                label: 'Feedback',
                data: [
                    analyticsData.feedback.positive,
                    analyticsData.feedback.neutral,
                    analyticsData.feedback.negative,
                ],
                backgroundColor: ['#4caf50', '#ffeb3b', '#f44336'],
                hoverBackgroundColor: ['#388e3c', '#fbc02d', '#d32f2f'],
            },
        ],
    };

    const questionData = {
        labels: analyticsData.questions.map((q) => q.question),
        datasets: [
            {
                label: 'Question Frequency',
                data: analyticsData.questions.map((q) => q.count),
                backgroundColor: '#2196f3',
                borderColor: '#1976d2',
                borderWidth: 1,
            },
        ],
    };

    // Event handlers
    const handleCategoryChange = (event) => {
        setCategory(event.target.value);
        // Update data based on selected category (API calls or state updates)
    };

    const handleUserChange = (event) => {
        setUser(event.target.value);
        // Update data based on selected user (API calls or state updates)
    };

    return (
        <Grid container spacing={3} style={{ padding: '20px' }}>
            {/* Header */}
            <Grid item xs={12}>
                <Typography variant="h4" style={{ textAlign: 'center', marginBottom: '20px' }}>
                    Analytics Dashboard
                </Typography>
            </Grid>

            {/* Filters */}
            <Grid item xs={6}>
                <Select
                    value={category}
                    onChange={handleCategoryChange}
                    fullWidth
                    displayEmpty
                    style={{ backgroundColor: '#f0f0f0', padding: '10px', borderRadius: '8px' }}
                >
                    <MenuItem value="">Select Category</MenuItem>
                    <MenuItem value="Category1">Category 1</MenuItem>
                    <MenuItem value="Category2">Category 2</MenuItem>
                </Select>
            </Grid>

            <Grid item xs={6}>
                <Select
                    value={user}
                    onChange={handleUserChange}
                    fullWidth
                    displayEmpty
                    style={{ backgroundColor: '#f0f0f0', padding: '10px', borderRadius: '8px' }}
                >
                    <MenuItem value="">Select User</MenuItem>
                    <MenuItem value="User1">User 1</MenuItem>
                    <MenuItem value="User2">User 2</MenuItem>
                </Select>
            </Grid>

            {/* Document & Chat Count */}
            <Grid item xs={6}>
                <Card style={{ backgroundColor: '#e3f2fd', textAlign: 'center' }}>
                    <CardContent>
                        <Typography variant="h5">Document Count</Typography>
                        <Typography variant="h4">{analyticsData.documents}</Typography>
                    </CardContent>
                </Card>
            </Grid>

            <Grid item xs={6}>
                <Card style={{ backgroundColor: '#fce4ec', textAlign: 'center' }}>
                    <CardContent>
                        <Typography variant="h5">Chat Count</Typography>
                        <Typography variant="h4">{analyticsData.chats}</Typography>
                    </CardContent>
                </Card>
            </Grid>

            {/* Feedback Chart */}
            <Grid item xs={12} md={6}>
                <Card style={{ padding: '20px' }}>
                    <Typography variant="h6">Feedback Distribution</Typography>
                    <Pie data={feedbackData} />
                </Card>
            </Grid>

            {/* Question Frequency Chart */}
            <Grid item xs={12} md={6}>
                <Card style={{ padding: '20px' }}>
                    <Typography variant="h6">Question Frequency</Typography>
                    <Bar data={questionData} options={{
                        plugins: {
                            legend: {
                                display: false,
                            },
                        },
                    }} />
                </Card>
            </Grid>

        </Grid>
    );
};


export default MuiAnalytics;