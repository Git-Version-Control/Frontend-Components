
import React from 'react'
// import MuiAnalytics from './components/MuiAnalytics'
// import TailwindAnalytics from './components/TailwindAnalytics'
import { AnalyticsPage } from './components/Analytics'
const App = () => {
  return (
    <>
      {/* <h1>Analytics Dashboard</h1> */}
      {/* <MuiAnalytics /> */}
      {/* <TailwindAnalytics /> */}
      <AnalyticsPage />
    </>
  )
}

export default App
